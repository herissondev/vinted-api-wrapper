from setuptools import setup, find_packages
import setuptools


    
VERSION = '0.0.1'
DESCRIPTION = 'Vinted API wrapper for python'

with open("README.md", "r", encoding="utf-8") as fh:
    LONG_DESCRIPTION = fh.read()

# Setting up
setup(
    # the name must match the folder name 'verysimplemodule'
    name="pyVinted-erisson",
    version=VERSION,
    author="Aimé Risson",
    author_email="aime.risson.1@gmail.fr",
    description=DESCRIPTION,
    long_description=LONG_DESCRIPTION,
    long_description_content_type="text/markdown",
    install_requires=['requests'], 
    keywords=['python', 'Vinted api', 'Vinted API wrapper', 'python vinted'],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Education",
        "Programming Language :: Python :: 2",
        "Programming Language :: Python :: 3",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.6",
)